import { useEffect, useMemo, useRef, useState } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Activity, ArrowDownRight, BrainCircuit, ChevronDown, Cpu, Database, FlaskConical, Gauge, GitBranch, Layers3, Menu, Moon, SearchCheck, Sun, X } from 'lucide-react'
import { defaultCase, familyNames, feedstockNames, metalNames, modificationNames, numericFields } from './data'
import { AmbientField, SectionTitle } from './components/AmbientField'
import { CandidateMap, ResponseProfile } from './components/Charts'
import { EvidenceNotice, Metric, NumberField, RunButton, SelectField, StrategyRow } from './components/FormControls'

gsap.registerPlugin(ScrollTrigger)

const navItems = [
  ['Workbench', 'workbench'],
  ['Evidence ledger', 'material'],
  ['Model core', 'intelligence'],
  ['Candidate screening', 'candidates'],
]

const visibleFields = numericFields.slice(0, 7)
const advancedFields = numericFields.slice(7)
const profileOptions = [['dosage', 'Dose'], ['initial_conc', 'Initial concentration'], ['kmno4_conc', 'KMnO4'], ['ph', 'pH'], ['contact_time', 'Contact time']]
const fieldLabels = Object.fromEntries(numericFields.map(([key, label]) => [key, label]))

function App() {
  const appRef = useRef(null)
  const requestId = useRef(0)
  const profileRequestId = useRef(0)
  const [form, setForm] = useState(defaultCase)
  const [meta, setMeta] = useState(null)
  const [result, setResult] = useState(null)
  const [plans, setPlans] = useState([])
  const [candidates, setCandidates] = useState([])
  const [objectives, setObjectives] = useState([])
  const [profile, setProfile] = useState(null)
  const [profileField, setProfileField] = useState('dosage')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [activePlan, setActivePlan] = useState('capacity')
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [mobileNav, setMobileNav] = useState(false)
  const [activeSection, setActiveSection] = useState('workbench')
  const [theme, setTheme] = useState(() => localStorage.getItem('mnevidence-theme') || 'dark')

  const update = (key, value) => setForm((current) => ({ ...current, [key]: value }))
  const goTo = (id) => {
    setActiveSection(id)
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    setMobileNav(false)
  }

  const predict = async (caseInput = form, withPlans = true) => {
    const currentRequest = ++requestId.current
    ++profileRequestId.current
    setLoading(true)
    setError('')
    try {
      if (withPlans) {
        const request = (url, body) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
        const [recommendationResponse, profileResponse] = await Promise.all([
          request('/api/recommend', caseInput), request('/api/profile', { case: caseInput, field: profileField }),
        ])
        const [recommendation, profileResult] = await Promise.all([recommendationResponse.json(), profileResponse.json()])
        if (currentRequest !== requestId.current) return
        if (!recommendationResponse.ok) throw new Error(recommendation.error || 'Candidate screening failed')
        if (!profileResponse.ok) throw new Error(profileResult.error || 'Response profile failed')
        setResult(recommendation.baseline)
        setPlans(recommendation.strategies)
        setCandidates(recommendation.candidate_set || [])
        setObjectives(recommendation.objectives || [])
        setProfile(profileResult)
      } else {
        const response = await fetch('/api/predict', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(caseInput) })
        const prediction = await response.json()
        if (currentRequest !== requestId.current) return
        if (!response.ok) throw new Error(prediction.error || 'Prediction failed')
        setResult(prediction)
      }
    } catch (caught) {
      if (currentRequest === requestId.current) setError(caught.message)
    } finally {
      if (currentRequest === requestId.current) setLoading(false)
    }
  }

  const changeProfile = async (field) => {
    const currentRequest = ++profileRequestId.current
    setProfileField(field)
    try {
      const response = await fetch('/api/profile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ case: result?.case || form, field }) })
      const body = await response.json()
      if (currentRequest !== profileRequestId.current) return
      if (!response.ok) throw new Error(body.error || 'Response profile failed')
      setProfile(body)
    } catch (caught) {
      if (currentRequest === profileRequestId.current) setError(caught.message)
    }
  }

  const applyPlan = (strategy) => {
    setActivePlan(strategy.id)
    setForm(strategy.result.case)
    predict(strategy.result.case, true)
  }

  useEffect(() => { fetch('/api/metadata').then(response => response.json()).then(body => { setMeta(body); setForm(body.defaults); predict(body.defaults) }).catch(caught => setError(caught.message)) }, [])

  useEffect(() => {
    localStorage.setItem('mnevidence-theme', theme)
    document.documentElement.style.colorScheme = theme
  }, [theme])

  useEffect(() => {
    const sections = navItems.map(([, id]) => document.getElementById(id)).filter(Boolean)
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)
      if (visible[0]) setActiveSection(visible[0].target.id)
    }, { rootMargin: '-22% 0px -60% 0px', threshold: [0.08, 0.22, 0.45] })
    sections.forEach((section) => observer.observe(section))
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined
    const context = gsap.context(() => {
      gsap.fromTo('.hero-copy > *', { autoAlpha: 0, y: 18 }, { autoAlpha: 1, y: 0, duration: 0.72, stagger: 0.1, ease: 'power3.out' })
      gsap.fromTo('.hero-results > *', { autoAlpha: 0, y: 18 }, { autoAlpha: 1, y: 0, duration: 0.72, delay: 0.24, stagger: 0.11, ease: 'power3.out' })
      gsap.utils.toArray('.reveal').forEach((element) => {
        gsap.fromTo(element, { autoAlpha: 0, y: 28 }, { autoAlpha: 1, y: 0, duration: 0.72, ease: 'power2.out', scrollTrigger: { trigger: element, start: 'top 82%' } })
      })
      gsap.to('.ambient-field svg', { xPercent: -2.5, duration: 16, yoyo: true, repeat: -1, ease: 'sine.inOut' })
    }, appRef)
    return () => context.revert()
  }, [])

  const coverage = result?.coverage
  const screenedMetals = meta?.screened_metals || ['Cd', 'Pb', 'Cu', 'Cr']
  const screeningAvailable = screenedMetals.includes(form.metal)
  const metalGroups = [
    { label: 'Screening scenarios', options: Object.fromEntries(['Cd', 'Pb', 'Cu', 'Cr'].filter(key => screenedMetals.includes(key)).map(key => [key, metalNames[key]])) },
    { label: 'Exploratory prediction only', options: Object.fromEntries(Object.entries(metalNames).filter(([key]) => !screenedMetals.includes(key))) },
  ]
  const coveragePosition = coverage?.level === 'high' ? '16%' : coverage?.level === 'medium' ? '52%' : '80%'
  const coverageText = useMemo(() => coverage?.inside_count != null ? `${coverage.inside_count}/${coverage.total_count} numeric inputs within the reference range` : 'Checking evidence support', [coverage])
  const boundaryFields = [...(coverage?.outside || []), ...(coverage?.boundary || [])]
  const selectedPlan = plans.find((item) => item.id === activePlan)

  return (
    <div className="mn-app" data-theme={theme} ref={appRef}>
      <header className="topbar">
        <button className="wordmark" onClick={() => goTo('workbench')} aria-label="Return to workbench"><span>MnEvidence AI</span><i>/</i><strong>Paper-linked screening</strong></button>
        <nav className={mobileNav ? 'mobile-open' : ''} aria-label="Main navigation">
          {navItems.map(([label, id]) => <button className={activeSection === id ? 'active' : ''} onClick={() => goTo(id)} key={id}>{label}</button>)}
        </nav>
        <div className="topbar-actions">
          <span className="runtime-dot">{result ? 'Local model connected' : 'Connecting'}</span>
          <button className="theme-button" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="Toggle theme" title="Toggle theme">{theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}</button>
          <button className="menu-button" onClick={() => setMobileNav(!mobileNav)} aria-label="Open navigation">{mobileNav ? <X size={20} /> : <Menu size={20} />}</button>
        </div>
      </header>

      <main>
        <section className="compute-canvas" id="workbench">
          <AmbientField />
          <div className="canvas-intro">
            <div className="hero-copy">
              <h1>Turn literature evidence<br />into auditable <em>AI</em> screening</h1>
              <p>Separate uptake and removal estimates connect literature evidence to support-aware candidate screening for Cd, Pb, Cu and Cr(VI) on KMnO4-modified carbon.</p>
              <button className="canvas-cta" onClick={() => { goTo('controls'); predict(form) }}>Run reference case <ArrowDownRight size={18} /></button>
            </div>
            <div className="hero-results" aria-label="Projected dual-response estimates">
              <div className="hero-reading q"><span>Projected uptake q</span><strong>{result?.q?.toFixed(1) ?? '—'}</strong><em>mg/g</em><i /></div>
              <div className="hero-reading r"><span>Projected removal R</span><strong>{result?.R?.toFixed(1) ?? '—'}</strong><em>%</em><i /></div>
            </div>
          </div>

          <div className="controls-rail" id="controls">
            <div className="rail-heading"><span>Operating context</span><small>Run after editing</small></div>
            <SelectField label="Target metal" value={form.metal} groups={metalGroups} onChange={(value) => { const next = meta?.metal_defaults[value]; if (next) { setForm(next); setResult(null); setPlans([]); setCandidates([]); setProfile(null); setActivePlan('capacity'); predict(next) } }} />
            {visibleFields.slice(0, 5).map((item) => <NumberField key={item[0]} item={item} value={form[item[0]]} onChange={(value) => update(item[0], value)} />)}
            <div className="rail-heading material-heading"><span>Material and preparation</span><button onClick={() => setShowAdvanced(!showAdvanced)}>{showAdvanced ? 'Hide' : 'More'}<ChevronDown size={14} className={showAdvanced ? 'flip' : ''} /></button></div>
            {visibleFields.slice(5).map((item) => <NumberField key={item[0]} item={item} value={form[item[0]]} onChange={(value) => update(item[0], value)} />)}
            {showAdvanced && <div className="advanced-inputs">
              <SelectField label="Sorbent family" value={form.adsorbent_family} options={familyNames} onChange={(value) => update('adsorbent_family', value)} />
              <SelectField label="Feedstock family" value={form.feedstock_family} options={feedstockNames} onChange={(value) => update('feedstock_family', value)} />
              <SelectField label="Modification class" value={form.modification_class} options={modificationNames} onChange={(value) => update('modification_class', value)} />
              {advancedFields.map((item) => <NumberField key={item[0]} item={item} value={form[item[0]]} onChange={(value) => update(item[0], value)} />)}
            </div>}
            <RunButton loading={loading || !meta} screening={screeningAvailable} onRun={() => predict(form)} onReset={() => { if (meta) { setForm(meta.defaults); predict(meta.defaults) } }} />
          </div>

          <div className="analysis-stage">
            {error && <div className="error-line" role="alert"><Activity size={15} />{error}</div>}
            <section className="analysis-panel result-panel">
              <div className="panel-topline"><span>{screeningAvailable ? 'Interactive estimate' : 'Exploratory prediction only'}</span><small>Frozen XGBoost backbones</small></div>
              <div className="metric-row"><Metric label="Uptake" symbol="q" value={result?.q} unit="mg/g" tone="blue" /><Metric label="Removal" symbol="R" value={result?.R} unit="%" tone="violet" /></div>
              <div className="coverage-line"><div><span>Evidence support</span><b className={coverage?.level || 'low'}>{coverage?.label || 'Checking'}</b></div><div className="coverage-track"><i className={coverage?.level || 'low'} style={{ left: coveragePosition }} /></div><p>{coverage?.message || coverageText}</p>{boundaryFields.length > 0 && <small>Review: {boundaryFields.slice(0, 4).map((key) => fieldLabels[key] || key).join(', ')}</small>}</div>
            </section>
            <section className="analysis-panel profile-panel">
              <div className="panel-topline"><span>Conditional response profile</span><div className="profile-switches">{profileOptions.map(([key, label]) => <button onClick={() => changeProfile(key)} className={profileField === key ? 'active' : ''} key={key}>{label}</button>)}</div></div>
              <ResponseProfile profile={profile} />
              <p className="chart-footnote">{profile?.note || 'Conditional model profile, not an experimental curve.'}</p>
            </section>
          </div>

          <div className="canvas-footer-flow"><span><Database size={15} />Encode context</span><b>→</b><span><BrainCircuit size={15} />Estimate q/R</span><b>→</b><span><SearchCheck size={15} />Screen candidates</span><b>→</b><span><FlaskConical size={15} />Compare conditions</span></div>
        </section>

        <section className="material-section" id="material">
          <div className="material-texture" aria-hidden="true" />
          <div className="material-layout reveal">
            <SectionTitle eyebrow="Reference application" title={<>A traceable domain across materials and metals</>} inverse>Material, modification, solution and process conditions are retained for comparing supported relationships across the literature.</SectionTitle>
            <div className="material-proofs">
              <article><b>1,297</b><span>evidence rows</span><p>Organized into 168 paper-series groups.</p></article>
              <article><b>63</b><span>source papers</span><p>Paper, series and label provenance retained.</p></article>
              <article><b>19</b><span>metal labels</span><p>Five carbon families; screening scenarios for Cd, Pb, Cu and Cr(VI).</p></article>
            </div>
            <div className="evidence-ledger">
              <div><Database size={18} /><span>Source layer</span><p>Publication, series and label origin</p></div>
              <div><GitBranch size={18} /><span>Model layer</span><p>Target-specific features and preprocessing</p></div>
              <div><SearchCheck size={18} /><span>Inference layer</span><p>Local support, profiles and candidates</p></div>
            </div>
            <div className="evidence-benchmarks" aria-label="Conditional reference ranges">
              <article><small>KMnO4-associated change</small><b>0.07 / 0.11</b><span>mol/L for q and R profiles</span></article>
              <article><small>Contact-time profile</small><b>4.4-5.4 h</b><span>Average gains weaken</span></article>
              <article><small>Metal-specific pH</small><b>about 6 / about 3</b><span>Cd/Pb/Cu and Cr(VI)</span></article>
            </div>
            <div className="material-caption"><span>Scope</span><p>Reference ranges vary with the represented material, metal and operating context.</p></div>
          </div>
        </section>

        <section className="intelligence-section" id="intelligence">
          <div className="intelligence-inner reveal">
            <SectionTitle eyebrow="Auditable model core" title={<>Research evaluation and screening keep distinct roles</>} inverse>The paper evaluates a cross-fitted ensemble. The tool uses the same frozen XGBoost response backbones as the paper's interpretation and decision layer.</SectionTitle>
            <div className="research-proof-line" aria-label="Research and screening model roles">
              <div><div className="proof-meta"><span>Research evaluation</span><b>Cross-fitted ensemble</b><i>10-fold OOF</i></div><div className="proof-metrics"><strong>q <small>R²</small> 0.910</strong><strong>R <small>R²</small> 0.861</strong></div></div>
              <div><div className="proof-meta"><span>Local screening</span><b>Bayesian XGBoost</b><i>Frozen development fits</i></div><div className="proof-metrics"><strong>q <small>backbone</small></strong><strong>R <small>backbone</small></strong></div></div>
            </div>
            <div className="method-stack">
              <article><Database size={22} /><div><h3>Source before sample</h3><p>Source identifiers, experimental series and label provenance stay attached to each evidence record.</p></div></article>
              <article><BrainCircuit size={22} /><div><h3>Separate response models</h3><p>q and R are fitted separately. Neither observed response enters the other response's predictors.</p></div></article>
              <article><Gauge size={22} /><div><h3>Fold-contained evaluation</h3><p>Ten-fold cross-fitting, 30 repeated splits and paper-cluster intervals quantify distinct aspects of performance.</p></div></article>
              <article><Layers3 size={22} /><div><h3>Supported interpretation</h3><p>Derived features are recomputed with their inputs. Local support constrains interpretation of sparse regions.</p></div></article>
              <article><FlaskConical size={22} /><div><h3>Conditional candidate choices</h3><p>NSGA-III compares two projected responses, oxidant concentration, process burden and screening risk.</p></div></article>
            </div>
            <div className="difference-grid" aria-label="Design choices">
              <div><small>Input</small><span>Literature data</span><b>Source-linked records</b></div>
              <div><small>Responses</small><span>Different preferences</span><b>Separate q and R models</b></div>
              <div><small>Interpretation</small><span>Variable-response profiles</span><b>Support-aware analysis</b></div>
              <div><small>Decision</small><span>Competing objectives</span><b>Conditional candidates</b></div>
            </div>
          </div>
        </section>

        <section className="candidate-section" id="candidates">
          <div className="candidate-inner reveal">
            <SectionTitle eyebrow="Decision output" title={<>Three preference modes for supported candidates</>}>Uptake-forward, removal-forward and balanced scores rank the same eligible set. Different scores may select the same condition.</SectionTitle>
            <div className="objective-strip">{objectives.map((objective) => <span key={objective}>{objective}</span>)}</div>
            <div className="candidate-layout">
              <div className="candidate-map-panel"><CandidateMap candidates={candidates} strategies={plans} /><p className="chart-footnote">Opacity reflects screening risk, not environmental safety. Points are conditional candidates from the five-objective search.</p></div>
              <div className="strategy-list-panel">
                <div className="strategy-panel-head"><span>Candidate strategies</span><small>{candidates.length || '—'} candidates</small></div>
                <div className="strategy-list">{plans.length ? plans.map((strategy) => <StrategyRow strategy={strategy} active={activePlan === strategy.id} onApply={applyPlan} key={strategy.id} />) : <div className="strategy-loading">{loading ? (screeningAvailable ? 'Generating candidates' : 'Computing exploratory estimates') : 'Prediction only for this metal. Screening scenarios are available for Cd, Pb, Cu and Cr(VI).'}</div>}</div>
                {selectedPlan && <div className="strategy-explanation"><span>Selected condition changes</span><p>{selectedPlan.result.changes.join('; ')}</p><div><i>KMnO4 {selectedPlan.result.decision.chemical.toFixed(3)}</i><i>Process burden {selectedPlan.result.decision.process.toFixed(3)}</i><i>Screening risk {selectedPlan.result.decision.boundary_risk.toFixed(3)}</i></div></div>}
              </div>
            </div>
            <EvidenceNotice>Literature-domain screening aid. Candidate conditions require verification; this tool is not an experimental substitute.</EvidenceNotice>
          </div>
        </section>
      </main>

      <footer><span>MnEvidence AI / Paper-linked screening</span><p>Local companion tool for KMnO4-modified carbon adsorption research</p></footer>
    </div>
  )
}

export default App
