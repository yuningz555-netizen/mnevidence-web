export const defaultCase = { metal: 'Pb' }

export const metalNames = {
  As: 'Arsenic (As)', Cd: 'Cadmium (Cd)', Co: 'Cobalt (Co)', Cr: 'Chromium (Cr(VI))', Cu: 'Copper (Cu)', Eu: 'Europium (Eu)', Fe: 'Iron (Fe)',
  La: 'Lanthanum (La)', Lu: 'Lutetium (Lu)', Mn: 'Manganese (Mn)', Ni: 'Nickel (Ni)', Pb: 'Lead (Pb)', Sb: 'Antimony (Sb)', Sc: 'Scandium (Sc)',
  Tl: 'Thallium (Tl)', U: 'Uranium (U)', Y: 'Yttrium (Y)', Yb: 'Ytterbium (Yb)', Zn: 'Zinc (Zn)',
}

export const familyNames = {
  biochar: 'Biochar', activated_carbon: 'Activated carbon', biochar_composite: 'Biochar composite',
  carbonaceous_biosorbent: 'Carbonaceous biosorbent', hydrochar: 'Hydrochar',
}

export const feedstockNames = Object.fromEntries(['astragalus_residue', 'bamboo', 'commercial_activated_carbon', 'corn_residue', 'cotton_residue', 'crop_straw', 'food_digestate_maize_straw_mix', 'fruit_shell', 'hydrothermal_biomass', 'loofah', 'millet_bran', 'nut_or_fruit_shell', 'other_or_unspecified', 'pineapple_waste', 'plane_tree_leaves', 'rice_residue', 'sludge_or_biosolid', 'spent_coffee', 'spinach_waste', 'wood_or_sawdust'].map(key => [key, key.replaceAll('_', ' ')]))

export const modificationNames = {
  KMnO4_modified: 'KMnO4 modified', KMnO4_co_modified: 'KMnO4 co-modified',
  KMnO4_plus_Fe_or_magnetic: 'KMnO4 + Fe / magnetic', MnOx_biochar_composite: 'MnOx-carbon composite',
  unmodified_or_control: 'Unmodified / control',
}

export const numericFields = [
  ['initial_conc', 'Initial concentration', 'mg/L', 0.1, 0.1], ['ph', 'Initial pH', '', 0.1, 0],
  ['dosage', 'Sorbent dose', 'g/L', 0.05, 0.05], ['contact_time', 'Contact time', 'h', 0.5, 0],
  ['adsorption_temp', 'Adsorption temperature', '°C', 1, 1], ['kmno4_conc', 'KMnO4 concentration', 'mol/L', 0.01, 0],
  ['mod_time', 'Modification time', 'h', 0.5, 0], ['mod_temp', 'Modification temperature', '°C', 1, 1],
  ['pyrolysis_temp', 'Pyrolysis temperature', '°C', 10, 10], ['bet_area', 'BET surface area', 'm²/g', 1, 0],
  ['pore_vol', 'Pore volume', 'cm³/g', 0.01, 0], ['pore_diameter', 'Pore diameter', 'nm', 0.1, 0],
  ['carbon_content', 'Carbon content', '%', 0.1, 0], ['oxygen_content', 'Oxygen content', '%', 0.1, 0], ['oc_ratio', 'O/C ratio', '', 0.01, 0],
]
