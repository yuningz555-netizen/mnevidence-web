import { Activity, ChevronDown, ChevronRight, CircleGauge, Droplets, RotateCcw, Scale, ShieldCheck, Sparkles, Target } from 'lucide-react'

export function SelectField({ label, value, options, groups, onChange }) {
  return (
    <label className="input-row">
      <span>{label}</span>
      <span className="input-control select-input">
        <select value={value} onChange={(event) => onChange(event.target.value)}>
          {groups ? groups.map(({ label: groupLabel, options: groupOptions }) => (
            <optgroup label={groupLabel} key={groupLabel}>
              {Object.entries(groupOptions).map(([key, name]) => <option value={key} key={key}>{name}</option>)}
            </optgroup>
          )) : Object.entries(options).map(([key, name]) => <option value={key} key={key}>{name}</option>)}
        </select>
        <ChevronDown size={14} />
      </span>
    </label>
  )
}

export function NumberField({ item, value, onChange }) {
  const [key, label, unit, step, minimum] = item
  return (
    <label className="input-row">
      <span>{label}</span>
      <span className="input-control number-input">
        <input type="number" step={step} min={minimum} value={value ?? ''} placeholder="Not reported" onChange={(event) => onChange(event.target.value === '' ? null : Number(event.target.value))} />
        {unit && <em>{unit}</em>}
      </span>
    </label>
  )
}

export function Metric({ label, symbol, value, unit, tone }) {
  return (
    <article className={`result-metric ${tone}`}>
      <span>{label}</span>
      <div><i>{symbol}</i><strong>{value == null ? '—' : value.toFixed(1)}</strong><em>{unit}</em></div>
      <small>Mass-balance-projected estimate</small>
    </article>
  )
}

export function StrategyRow({ strategy, active, onApply }) {
  const iconMap = { capacity: Target, removal: Droplets, balanced: Scale }
  const Icon = iconMap[strategy.id] || Sparkles
  return (
    <button className={`strategy-row ${active ? 'active' : ''}`} aria-pressed={active} onClick={() => onApply(strategy)}>
      <span className="strategy-icon"><Icon size={17} /></span>
      <span className="strategy-text"><strong>{strategy.title}</strong><small>{strategy.subtitle}</small></span>
      <span className="strategy-value"><b>{strategy.result.q.toFixed(1)}</b><small>q</small></span>
      <span className="strategy-value"><b>{strategy.result.R.toFixed(1)}</b><small>R</small></span>
      <ChevronRight size={16} />
    </button>
  )
}

export function RunButton({ loading, screening = true, onRun, onReset }) {
  return (
    <div className="run-actions">
      <button className="reset-button" onClick={onReset} title="Reset to reference context"><RotateCcw size={15} />Reset</button>
      <button className="run-button" onClick={onRun} disabled={loading}>
        {loading ? <Activity size={16} className="spin" /> : <CircleGauge size={16} />}
        {loading ? 'Computing' : screening ? 'Run screening' : 'Run prediction'}
      </button>
    </div>
  )
}

export function EvidenceNotice({ children }) {
  return <p className="evidence-notice"><ShieldCheck size={14} />{children}</p>
}
