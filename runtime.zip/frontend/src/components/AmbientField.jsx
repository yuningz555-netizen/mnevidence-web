export function AmbientField({ className = '' }) {
  return (
    <div className={`ambient-field ${className}`} aria-hidden="true">
      <svg viewBox="0 0 1440 560" preserveAspectRatio="none">
        <g className="ambient-lines">
          <path d="M-50 120 C120 30 210 230 390 140 S630 60 780 150 S1080 230 1490 80" />
          <path d="M-40 175 C170 70 255 275 450 178 S650 95 825 188 S1130 270 1490 130" />
          <path d="M-35 230 C118 160 290 330 475 218 S680 140 880 242 S1130 315 1490 210" />
          <path d="M-50 305 C120 210 275 410 475 294 S700 210 905 310 S1190 370 1490 280" />
          <path d="M-40 385 C155 285 295 485 520 367 S750 290 985 390 S1190 445 1490 350" />
          <path d="M-50 455 C115 360 335 555 560 435 S780 360 1040 452 S1230 512 1490 430" />
        </g>
        <g className="ambient-points">
          {[[128,112],[214,192],[356,145],[520,206],[664,128],[782,174],[930,112],[1088,192],[1235,125],[1340,186],[93,325],[289,392],[456,313],[612,408],[788,322],[958,412],[1136,345],[1300,390]].map(([cx, cy], index) => (
            <circle key={`${cx}-${cy}`} cx={cx} cy={cy} r={index % 4 === 0 ? 3 : 1.6} />
          ))}
        </g>
      </svg>
    </div>
  )
}

export function SectionTitle({ eyebrow, title, children, inverse = false }) {
  return (
    <header className={`section-title ${inverse ? 'inverse' : ''}`}>
      <div>
        <span className="section-eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
      </div>
      {children && <p>{children}</p>}
    </header>
  )
}
