function linePath(points, project) {
  return points.map((point, index) => `${index ? 'L' : 'M'}${project(point).join(',')}`).join(' ')
}

export function ResponseProfile({ profile }) {
  if (!profile?.points?.length) return <div className="chart-empty">Loading response profile</div>
  const width = 760; const height = 292; const pad = { left: 54, right: 58, top: 36, bottom: 42 }
  const values = profile.points
  const extent = (source) => {
    const min = Math.min(...source); const max = Math.max(...source); const span = Math.max(max - min, 1)
    return [min - span * 0.08, max + span * 0.08]
  }
  const [xMin, xMax] = extent(values.map((item) => item.x))
  const [qMin, qMax] = extent(values.map((item) => item.q))
  const [rMin, rMax] = extent(values.map((item) => item.R))
  const x = (value) => pad.left + ((value - xMin) / (xMax - xMin)) * (width - pad.left - pad.right)
  const yQ = (value) => pad.top + (1 - (value - qMin) / (qMax - qMin)) * (height - pad.top - pad.bottom)
  const yR = (value) => pad.top + (1 - (value - rMin) / (rMax - rMin)) * (height - pad.top - pad.bottom)
  const baseX = x(Math.max(xMin, Math.min(xMax, profile.baseline_x)))
  return (
    <div className="chart-shell response-chart-shell">
      <div className="chart-key"><span className="q-key">Uptake q</span><span className="r-key">Removal R</span><span className="current-key">Current input</span></div>
      <svg viewBox={`0 0 ${width} ${height}`} className="chart-svg" role="img" aria-label={`Dual-response profile for ${profile.label}`}>
        {[0, 1, 2, 3].map((step) => <line key={step} x1={pad.left} x2={width - pad.right} y1={pad.top + step * (height - pad.top - pad.bottom) / 3} y2={pad.top + step * (height - pad.top - pad.bottom) / 3} className="chart-grid" />)}
        <line x1={baseX} x2={baseX} y1={pad.top} y2={height - pad.bottom} className="chart-baseline" />
        <path d={linePath(values, (item) => [x(item.x), yQ(item.q)])} className="chart-line-q" />
        <path d={linePath(values, (item) => [x(item.x), yR(item.R)])} className="chart-line-r" />
        {values.map((item, index) => <g key={`${item.x}-${index}`}><circle cx={x(item.x)} cy={yQ(item.q)} r="3" className="chart-dot-q"><title>{`${profile.label} ${item.x}${profile.unit}, q ${item.q} mg/g`}</title></circle><circle cx={x(item.x)} cy={yR(item.R)} r="3" className="chart-dot-r"><title>{`${profile.label} ${item.x}${profile.unit}, R ${item.R}%`}</title></circle></g>)}
        <text x={pad.left} y={height - 14} className="chart-label">{values[0].x.toFixed(2)}</text>
        <text x={width / 2} y={height - 14} className="chart-label center">{profile.label} {profile.unit ? `(${profile.unit})` : ''}</text>
        <text x={width - pad.right} y={height - 14} className="chart-label end">{values.at(-1).x.toFixed(2)}</text>
        {[0, 1, 2, 3].map(step => <g key={`axis-${step}`}><text x={pad.left - 8} y={pad.top + step * (height - pad.top - pad.bottom) / 3 + 3} className="chart-label end">{(qMax - step * (qMax - qMin) / 3).toFixed(1)}</text><text x={width - pad.right + 8} y={pad.top + step * (height - pad.top - pad.bottom) / 3 + 3} className="chart-label">{(rMax - step * (rMax - rMin) / 3).toFixed(1)}</text></g>)}
        <text x={pad.left} y="15" className="chart-label q-axis">q (mg/g)</text><text x={width - pad.right} y="15" className="chart-label r-axis end">R (%)</text>
      </svg>
    </div>
  )
}

export function CandidateMap({ candidates, strategies }) {
  if (!candidates?.length) return <div className="chart-empty">Screening available for Pb, Cd, Cu and Cr(VI)</div>
  const width = 590; const height = 292; const pad = { left: 46, right: 20, top: 36, bottom: 42 }
  const qValues = candidates.map((item) => item.q); const rValues = candidates.map((item) => item.R)
  const qMin = Math.min(...qValues); const qMax = Math.max(...qValues); const rMin = Math.min(...rValues); const rMax = Math.max(...rValues)
  const x = (value) => pad.left + ((value - qMin) / Math.max(qMax - qMin, 1)) * (width - pad.left - pad.right)
  const y = (value) => pad.top + (1 - (value - rMin) / Math.max(rMax - rMin, 1)) * (height - pad.top - pad.bottom)
  const strategyColor = { capacity: '#158b7a', removal: '#2f72e8', balanced: '#596a85' }
  const markers = []
  for (const strategy of strategies) {
    const match = markers.find(item => Math.abs(item.q - strategy.result.q) < 1e-6 && Math.abs(item.R - strategy.result.R) < 1e-6)
    const letter = strategy.id === 'capacity' ? 'A' : strategy.id === 'removal' ? 'B' : 'C'
    if (match) { match.letters.push(letter); match.titles.push(strategy.title) }
    else markers.push({ q: strategy.result.q, R: strategy.result.R, letters: [letter], titles: [strategy.title], color: strategyColor[strategy.id] })
  }
  return (
    <div className="chart-shell candidate-chart-shell">
      <div className="chart-key"><span className="candidate-key">Candidates</span><span className="pareto-key">5-objective set</span><span className="strategy-key">Strategies</span></div>
      <svg viewBox={`0 0 ${width} ${height}`} className="chart-svg" role="img" aria-label="Projected candidate uptake and removal">
        {[0, 1, 2, 3].map((step) => <line key={step} x1={pad.left} x2={width - pad.right} y1={pad.top + step * (height - pad.top - pad.bottom) / 3} y2={pad.top + step * (height - pad.top - pad.bottom) / 3} className="chart-grid" />)}
        {candidates.map((item) => <circle key={item.id} cx={x(item.q)} cy={y(item.R)} r={item.eligible ? 4 : 2.5} className={item.eligible ? 'candidate-dot pareto' : 'candidate-dot'} opacity={0.28 + (1 - Math.min(1, Math.max(0, item.boundary_risk))) * 0.58}><title>{`${item.id}: q ${item.q.toFixed(2)} mg/g; R ${item.R.toFixed(2)}%; screening risk ${item.boundary_risk.toFixed(3)}`}</title></circle>)}
        {markers.map(marker => <g key={marker.letters.join('/')}><title>{marker.titles.join(' / ')}</title><circle cx={x(marker.q)} cy={y(marker.R)} r={marker.letters.length > 1 ? 13 : 9} fill={marker.color} className="strategy-halo" /><text x={x(marker.q)} y={y(marker.R) + 3.5} className="strategy-letter">{marker.letters.join('/')}</text></g>)}
        {[0, 1, 2, 3].map(step => <text key={`axis-${step}`} x={pad.left - 8} y={pad.top + step * (height - pad.top - pad.bottom) / 3 + 3} className="chart-label end">{(rMax - step * (rMax - rMin) / 3).toFixed(1)}</text>)}
        <text x={pad.left} y={height - 14} className="chart-label">{qMin.toFixed(0)}</text><text x={width / 2} y={height - 14} className="chart-label center">Uptake q (mg/g)</text><text x={width - pad.right} y={height - 14} className="chart-label end">{qMax.toFixed(0)}</text><text x={pad.left} y="15" className="chart-label r-axis">Removal R (%)</text>
      </svg>
      <p className="chart-footnote">A: uptake-forward. B: removal-forward. C: balanced.</p>
    </div>
  )
}
