import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
import app as server
import model_runtime as runtime


class RuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.golden = json.loads((ROOT / "tests/golden_predictions.json").read_text(encoding="utf-8"))

    def test_golden_predictions(self):
        inputs = [runtime.normalise_payload(case["input"]) for case in self.golden["cases"]]
        predictions = runtime.predict_many(inputs)
        for expected, actual in zip(self.golden["cases"], predictions):
            for field in ["q", "R", "q_raw", "R_raw"]:
                # XGBoost's float32 predictions can differ by one ULP across platforms.
                np.testing.assert_allclose(actual[field], expected[field], rtol=1e-6, atol=1e-6)

    def test_archived_strategies(self):
        for metal, expected in self.golden["default_strategies"].items():
            result = runtime.recommend({"metal": metal})
            for wanted, actual in zip(expected, result["strategies"]):
                self.assertEqual(actual["id"], wanted["id"])
                np.testing.assert_allclose([actual["result"]["q"], actual["result"]["R"]],
                                           [wanted["q"], wanted["R"]], rtol=1e-12, atol=1e-10)

    def test_sparse_metals_prediction_only(self):
        for metal in set(runtime.DATA["contexts"]) - set(runtime.DATA["supports"]):
            result = runtime.recommend({"metal": metal})
            self.assertEqual(result["strategies"], [])
            self.assertEqual(result["candidate_set"], [])
            self.assertIsNone(result["baseline"]["coverage"]["screening_risk"])

    def test_input_errors_and_limits(self):
        client = server.app.test_client()
        for body in [[], {"metal": "invalid"}, {"dosage": -1}, {"ph": 15}, {"initial_conc": 0}]:
            self.assertEqual(client.post("/api/predict", json=body).status_code, 400)
        oversized = client.post("/api/predict", data=b" " * (64 * 1024 + 1), content_type="application/json")
        self.assertEqual(oversized.status_code, 413)
        self.assertIn("64 KB", oversized.json["error"])

    def test_busy_and_failure_recovery(self):
        client = server.app.test_client()
        server.screening_slot.acquire()
        try:
            result = client.post("/api/recommend", json={})
            self.assertEqual(result.status_code, 429)
            self.assertEqual(result.headers["Retry-After"], "5")
            self.assertEqual(client.get("/api/health").status_code, 200)
        finally:
            server.screening_slot.release()
        with patch.object(server, "recommend", side_effect=RuntimeError("test failure")), self.assertLogs(server.app.logger, level="ERROR"):
            self.assertEqual(client.post("/api/recommend", json={}).status_code, 500)
        self.assertTrue(server.screening_slot.acquire(blocking=False))
        server.screening_slot.release()

    def test_static_and_private_files(self):
        client = server.app.test_client()
        result = client.get("/")
        self.assertEqual(result.status_code, 200)
        self.assertIn("text/html", result.content_type)
        self.assertEqual(result.headers["Cache-Control"], "no-store")
        self.assertEqual(result.headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(client.get("/api/unknown").status_code, 404)
        self.assertNotIn(b"Evidence_Note", client.get("/api/metadata").data)
        for route in ["/backend/assets/support_contexts.json", "/backend/assets/q_XGBoost_Bayesian.joblib"]:
            self.assertIn("text/html", client.get(route).content_type)


if __name__ == "__main__":
    unittest.main()
