from __future__ import annotations
import numpy as np
import pandas as pd

def resolve_column(frame: pd.DataFrame, prefix: str) -> str:
    matches = [name for name in frame.columns if str(name).startswith(prefix)]
    if len(matches) > 1:
        unit_headers = [name for name in matches if "(" in str(name) and ")" in str(name)]
        if len(unit_headers) == 1:
            return unit_headers[0]
    if len(matches) != 1:
        raise KeyError(f"Expected one column starting with {prefix!r}, got {matches}")
    return matches[0]

def safe_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").astype(float)

METAL_PROPERTIES = {
    "Cd": (48, 112.414, 1.69, 95.0, 2.0),
    "Pb": (82, 207.200, 2.33, 119.0, 2.0),
    "Cu": (29, 63.546, 1.90, 73.0, 2.0),
    "Cr": (24, 51.996, 1.66, 44.0, 6.0),
    "U": (92, 238.029, 1.38, 73.0, 6.0),
    "Zn": (30, 65.380, 1.65, 74.0, 2.0),
    "Fe": (26, 55.845, 1.83, 65.0, 3.0),
    "Ni": (28, 58.693, 1.91, 69.0, 2.0),
    "Sb": (51, 121.760, 2.05, 76.0, 3.0),
    "As": (33, 74.922, 2.18, 46.0, 5.0),
    "Mn": (25, 54.938, 1.55, 83.0, 2.0),
    "Tl": (81, 204.380, 1.62, 150.0, 1.0),
    "Co": (27, 58.933, 1.88, 74.5, 2.0),
    "Sc": (21, 44.956, 1.36, 74.5, 3.0),
    "La": (57, 138.905, 1.10, 103.2, 3.0),
    "Yb": (70, 173.045, 1.10, 86.8, 3.0),
    "Lu": (71, 174.967, 1.27, 86.1, 3.0),
    "Y": (39, 88.906, 1.22, 90.0, 3.0),
    "Eu": (63, 151.964, 1.20, 94.7, 3.0),
}

def experiment_design(series: pd.Series) -> pd.Series:
    text = series.astype("string").fillna("unclassified").str.lower()
    output = pd.Series("other_or_endpoint", index=series.index, dtype="string")
    rules = [
        (r"kinetic|time", "kinetic_time"),
        (r"\bph\b|_ph|ph_", "pH"),
        (r"dosage|dose|mass", "adsorbent_dosage"),
        (r"isotherm|initial_concentration|concentration", "concentration_isotherm"),
        (r"adsorption_temperature", "adsorption_temperature"),
        (r"activation_temperature", "activation_temperature"),
        (r"modification|kmno4|screen", "modification_design"),
        (r"competition", "competitive_adsorption"),
        (r"orthogonal", "orthogonal_design"),
        (r"unclassified", "unclassified"),
    ]
    for pattern, label in rules:
        output = output.mask(text.str.contains(pattern, regex=True, na=False), label)
    return output

def add_engineered_features(frame: pd.DataFrame) -> pd.DataFrame:
    x = frame.copy()
    c_kmn = resolve_column(x, "KMnO4_Conc")
    c_mod_temp = resolve_column(x, "Mod_Temp")
    c_mod_time = resolve_column(x, "Mod_Time")
    c_ads_temp = resolve_column(x, "Adsorption_Temp")
    c_pyro = resolve_column(x, "Pyrolysis_Temp")
    c_bet = resolve_column(x, "BET_Area")
    c_pore = resolve_column(x, "Pore_Vol")

    kmno4 = safe_numeric(x[c_kmn])
    kmno4_feedstock_ratio = safe_numeric(x["KMnO4_to_Feedstock_Mass_Ratio"])
    kmno4_solution_fraction = safe_numeric(x["KMnO4_Solution_Mass_Fraction"])
    mod_temp = safe_numeric(x[c_mod_temp])
    mod_time = safe_numeric(x[c_mod_time])
    ads_temp = safe_numeric(x[c_ads_temp])
    pyro = safe_numeric(x[c_pyro])
    bet = safe_numeric(x[c_bet])
    pore = safe_numeric(x[c_pore])
    ph = safe_numeric(x["pH"])
    dose = safe_numeric(x["Dosage(g/L)"])
    contact = safe_numeric(x["Time(h)"])
    c0 = safe_numeric(x["Initial_Conc(mg/L)"])
    oxygen = safe_numeric(x["O_Content"])

    x["Experiment_Design_Class"] = experiment_design(x["Experiment_Series"])
    x["log1p_C0"] = np.log1p(c0.clip(lower=0))
    x["log1p_Dosage"] = np.log1p(dose.clip(lower=0))
    x["log1p_Time"] = np.log1p(contact.clip(lower=0))
    x["log1p_KMnO4_mM"] = np.log1p((1000.0 * kmno4).clip(lower=0))
    x["log1p_KMnO4_Feedstock_Ratio_x100"] = np.log1p(
        (100.0 * kmno4_feedstock_ratio).clip(lower=0)
    )
    x["log1p_KMnO4_Solution_Fraction_x100"] = np.log1p(
        (100.0 * kmno4_solution_fraction).clip(lower=0)
    )
    x["log1p_BET"] = np.log1p(bet.clip(lower=0))
    x["log1p_PoreVol"] = np.log1p(pore.clip(lower=0))

    # Physically interpretable upper bound when removal is 100%.
    x["CBR_Challenge_Burden_Ratio"] = c0 / dose.replace(0, np.nan)
    x["log1p_CBR"] = np.log1p(x["CBR_Challenge_Burden_Ratio"].clip(lower=0))

    # Compact, declared proxies rather than unrestricted polynomial expansion.
    x["OSTI_Oxidative_Severity_Index"] = (
        x["log1p_KMnO4_mM"]
        * ((mod_temp + 273.15) / 298.15)
        * np.log1p(mod_time.clip(lower=0))
    )
    x["TCEI_Thermal_Contact_Exposure_Index"] = (
        ((ads_temp + 273.15) / 298.15) * np.log1p(contact.clip(lower=0))
    )
    x["PSAI_Pore_Surface_Accessibility_Index"] = (
        np.log1p(bet.clip(lower=0)) * np.sqrt(pore.clip(lower=0))
    )
    x["OSAI_Oxygenated_Surface_Accessibility_Index"] = (
        np.log1p(bet.clip(lower=0)) * (oxygen / 100.0)
    )
    x["ASBI_Areal_Sorbate_Burden_Index"] = (
        c0 / (dose.replace(0, np.nan) * bet.replace(0, np.nan))
    )
    # Removal-oriented resource-sufficiency proxies. These invert the
    # capacity-oriented burden view and ask how much sorbent/surface/exposure
    # is supplied per unit dissolved-metal challenge.
    dose_to_c0 = dose / c0.replace(0, np.nan)
    x["SSR_Sorbent_Solute_Ratio"] = dose_to_c0
    x["log1p_SSR_x1000"] = np.log1p((1000.0 * dose_to_c0).clip(lower=0))
    x["SSEI_Surface_Supply_Exposure_Index"] = (
        bet * dose / c0.replace(0, np.nan)
    )
    x["OASI_Oxygenated_Areal_Supply_Index"] = (
        bet * (oxygen / 100.0) * dose / c0.replace(0, np.nan)
    )
    x["SEAI_Solid_Exposure_Adequacy_Index"] = (
        dose * np.log1p(contact.clip(lower=0)) / c0.replace(0, np.nan)
    )
    x["DCTI_Dose_Contact_Time_Interaction"] = (
        np.log1p(dose.clip(lower=0)) * np.log1p(contact.clip(lower=0))
    )
    x["KMnO4_Time_Interaction"] = kmno4 * mod_time
    x["KMnO4_Temperature_Interaction"] = kmno4 * mod_temp
    x["Adsorption_Temperature_Time_Interaction"] = ads_temp * contact
    x["pH_centered_7"] = ph - 7.0
    x["pH_centered_7_squared"] = (ph - 7.0) ** 2
    x["Pyrolysis_Modification_Temperature_Gap"] = pyro - mod_temp
    x["MSPI_Modification_Supply_Provision_Index"] = (
        x["OSTI_Oxidative_Severity_Index"] * x["log1p_SSR_x1000"]
    )

    metal = x["Metal_Type"].astype("string")
    prop_names = [
        "Metal_Atomic_Number",
        "Metal_Atomic_Mass",
        "Metal_Pauling_Electronegativity",
        "Metal_Ionic_Radius_pm",
        "Metal_Nominal_Valence",
    ]
    for position, name in enumerate(prop_names):
        x[name] = metal.map(
            {element: values[position] for element, values in METAL_PROPERTIES.items()}
        )
    x["MIP_Metal_Ionic_Potential"] = (
        x["Metal_Nominal_Valence"] / x["Metal_Ionic_Radius_pm"]
    )
    x["PHVI_pH_Valence_Interaction"] = ph * x["Metal_Nominal_Valence"]
    return x
