"""Frozen manuscript response backbones and conditional decision screening."""
from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.neighbors import NearestNeighbors

from feature_engineering import add_engineered_features

ASSETS = Path(__file__).parent / 'assets'
DATA = json.loads((ASSETS / 'support_contexts.json').read_text(encoding='utf-8'))
MANIFEST = json.loads((ASSETS / 'model_manifest.json').read_text(encoding='utf-8'))
CONTROL = DATA['control']
FIELDS = {
    'kmno4_conc': 'KMnO4_Conc(mol/L)', 'ph': 'pH', 'dosage': 'Dosage(g/L)',
    'contact_time': 'Time(h)', 'mod_temp': 'Mod_Temp(°C)', 'mod_time': 'Mod_Time(h)',
    'initial_conc': 'Initial_Conc(mg/L)', 'adsorption_temp': 'Adsorption_Temp(°C)',
    'pyrolysis_temp': 'Pyrolysis_Temp(°C)', 'bet_area': 'BET_Area(m²/g)',
    'pore_vol': 'Pore_Vol(cm³/g)', 'pore_diameter': 'Pore_Diameter_nm',
    'carbon_content': 'C_Content', 'oxygen_content': 'O_Content', 'oc_ratio': 'O/C_Ratio',
    'adsorbent_family': 'Adsorbent_Family', 'feedstock_family': 'Feedstock_Family',
    'modification_class': 'Modification_Class',
}
LABELS = {'kmno4_conc': ('KMnO4 concentration', 'mol/L'), 'ph': ('Initial pH', ''),
          'dosage': ('Sorbent dose', 'g/L'), 'contact_time': ('Contact time', 'h'),
          'mod_temp': ('Modification temperature', '°C'), 'mod_time': ('Modification time', 'h'),
          'initial_conc': ('Initial concentration', 'mg/L')}
IDS = {'uptake-forward': 'capacity', 'removal-forward': 'removal', 'balanced': 'balanced'}
TITLES = {'capacity': 'Uptake-forward', 'removal': 'Removal-forward', 'balanced': 'Balanced'}


def defaults(metal='Pb'):
    context = DATA['contexts'][metal]
    return {'metal': metal, **{key: context.get(column) for key, column in FIELDS.items()}}


def normalise_payload(payload=None):
    if payload is None:
        payload = {}
    if not isinstance(payload, dict):
        raise ValueError('The case must be a JSON object.')
    metal = str(payload.get('metal', 'Pb'))
    if metal not in DATA['contexts']:
        raise ValueError('Select a represented metal label.')
    case = {**defaults(metal), **{k: v for k, v in payload.items() if k in FIELDS}, 'metal': metal}
    for key, column in FIELDS.items():
        if key in ['adsorbent_family', 'feedstock_family', 'modification_class']:
            allowed = DATA[{'adsorbent_family': 'families', 'feedstock_family': 'feedstocks', 'modification_class': 'modifications'}[key]]
            if case[key] not in allowed:
                raise ValueError(f'Unsupported {key}.')
        elif case[key] is not None:
            try:
                case[key] = float(case[key])
            except (TypeError, ValueError):
                raise ValueError(f'{key} must be numeric or null.')
            if not np.isfinite(case[key]):
                raise ValueError(f'{key} must be finite.')
    for key in ['initial_conc', 'dosage']:
        if case[key] is None or case[key] <= 0:
            raise ValueError(f'{key} must be positive.')
    for key in ['kmno4_conc', 'contact_time', 'mod_time', 'bet_area', 'pore_vol', 'pore_diameter', 'oc_ratio']:
        if case[key] is not None and case[key] < 0:
            raise ValueError(f'{key} cannot be negative.')
    if case['ph'] is not None and not 0 <= case['ph'] <= 14:
        raise ValueError('pH must be between 0 and 14.')
    for key in ['mod_temp', 'adsorption_temp', 'pyrolysis_temp']:
        if case[key] is not None and case[key] <= -273.15:
            raise ValueError(f'{key} must exceed absolute zero.')
    for key in ['carbon_content', 'oxygen_content']:
        if case[key] is not None and not 0 <= case[key] <= 100:
            raise ValueError(f'{key} must be between 0 and 100.')
    return case


@lru_cache(maxsize=1)
def models():
    store = {}
    for name, digest in MANIFEST['models'].items():
        path = ASSETS / name
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise RuntimeError('Frozen model integrity check failed.')
        store[name[0]] = joblib.load(path)
    return store


def raw_frame(cases):
    rows = []
    for case in cases:
        row = dict(DATA['contexts'][case['metal']])
        row.update({column: np.nan if case[key] is None else case[key] for key, column in FIELDS.items()})
        row['Metal_Type'] = case['metal']
        row['Adsorbent_Class'] = int(case['adsorbent_family'] == 'activated_carbon')
        rows.append(row)
    return pd.DataFrame(rows)


def project(q_raw, r_raw, c0, dose):
    alpha = 100 * np.asarray(dose) / np.asarray(c0)
    wq, wr = 1 / 14.98**2, 1 / 11.58**2
    q = np.clip((wq * q_raw + wr * alpha * r_raw) / (wq + wr * alpha**2), 0, np.asarray(c0) / dose)
    return q, alpha * q, np.abs(alpha * q_raw - r_raw)


@lru_cache(maxsize=4)
def support(metal):
    item = DATA['supports'][metal]
    lower, upper = np.array(item['lower']), np.array(item['upper'])
    scale = upper - lower
    nn = NearestNeighbors(n_neighbors=min(5, len(item['support']))).fit((np.array(item['support']) - lower) / scale)
    pool = pd.read_csv(ASSETS / 'pareto_candidates.csv')
    cutoff = float(pool.loc[pool.metal == metal, 'prediction_risk'].quantile(.65))
    return lower, upper, scale, nn, cutoff


def predict_many(cases):
    raw = raw_frame(cases)
    frame = add_engineered_features(raw)
    q_raw = np.maximum(models()['q'].predict(frame), 0)
    r_raw = np.clip(models()['R'].predict(frame), 0, 100)
    q, r, residual = project(q_raw, r_raw, raw['Initial_Conc(mg/L)'].to_numpy(float), raw['Dosage(g/L)'].to_numpy(float))
    distances = {}
    for metal in {case['metal'] for case in cases} & set(DATA['supports']):
        indices = [i for i, case in enumerate(cases) if case['metal'] == metal and all(case[key] is not None for key in LABELS)]
        if indices:
            lower, _, scale, nn, _ = support(metal)
            z = (raw.iloc[indices][CONTROL].to_numpy(float) - lower) / scale
            distances.update(zip(indices, nn.kneighbors(z)[0].mean(axis=1)))
    output = []
    for i, case in enumerate(cases):
        outside, boundary, missing = [], [], []
        for key, column in FIELDS.items():
            if column not in DATA['ranges']:
                continue
            value = case[key]
            if value is None:
                missing.append(key)
                continue
            lo, p05, p95, hi = DATA['ranges'][column]
            if value < lo or value > hi:
                outside.append(key)
            elif value < p05 or value > p95:
                boundary.append(key)
        risk = distance = burden = chemical = None
        if case['metal'] in DATA['supports'] and all(case[key] is not None for key in LABELS):
            lower, upper, scale, nn, cutoff = support(case['metal'])
            x = raw[CONTROL].to_numpy(float)[i]
            z = (x - lower) / scale
            distance = float(distances[i])
            risk = distance + .35 * float(residual[i]) / 100
            chemical, burden = float(z[0]), float(np.mean(z[2:]))
            for column, value, lo, hi in zip(CONTROL, x, lower, upper):
                key = next(k for k, c in FIELDS.items() if c == column)
                if (value < lo or value > hi) and key not in boundary:
                    boundary.append(key)
        else:
            cutoff = None
        context_changed = any(case[k] != defaults(case['metal'])[k] for k in ['adsorbent_family', 'feedstock_family', 'modification_class'])
        level = 'low' if outside or risk is None else ('medium' if boundary or missing or context_changed or risk > cutoff else 'high')
        coverage = {'level': level, 'label': {'high': 'Within screening reference', 'medium': 'Check local support', 'low': 'Outside screening reference'}[level],
                    'message': 'd5NN uses the six operating controls; material edits and imputed descriptors need separate review.',
                    'outside': outside, 'boundary': boundary, 'missing': missing, 'inside_count': 15-len(set(outside+boundary+missing)), 'total_count': 15,
                    'd5NN': distance, 'screening_risk': risk, 'reference_cutoff': cutoff}
        output.append({'case': case, 'q': float(q[i]), 'R': float(r[i]), 'q_raw': float(q_raw[i]), 'R_raw': float(r_raw[i]),
                       'mass_balance_disagreement_pp': float(residual[i]), 'coverage': coverage,
                       'decision': {'chemical': chemical, 'process': burden, 'boundary_risk': risk},
                       'model_scope': 'Frozen Bayesian XGBoost response backbones; q/R shown after mass-balance projection.'})
    return output


def predict(payload=None):
    return predict_many([normalise_payload(payload)])[0]


def changes(original, candidate):
    return [f'{label}: {original[key]:.3g} -> {candidate[key]:.3g} {unit}'.strip()
            for key, (label, unit) in LABELS.items() if original.get(key) is not None and candidate[key] != original[key]] or ['Reference conditions unchanged.']


@lru_cache(maxsize=16)
def screen(case_json):
    from pymoo.algorithms.moo.nsga3 import NSGA3
    from pymoo.core.problem import Problem
    from pymoo.optimize import minimize
    from pymoo.util.ref_dirs import get_reference_directions

    case = json.loads(case_json)
    metal = case['metal']
    if metal not in DATA['supports']:
        return None
    lower, upper, scale, nn, _ = support(metal)
    if case == defaults(metal):
        pool = pd.read_csv(ASSETS / 'pareto_candidates.csv')
        return pool.loc[pool.metal == metal].copy(), 'Archived manuscript scenario'

    class ScreenProblem(Problem):
        def __init__(self):
            super().__init__(n_var=6, n_obj=5, xl=lower, xu=upper)

        def _evaluate(self, x, out, *args, **kwargs):
            cases = [{**case, **{next(k for k, c in FIELDS.items() if c == column): float(x[i,j]) for j, column in enumerate(CONTROL)}} for i in range(len(x))]
            raw = raw_frame(cases)
            frame = add_engineered_features(raw)
            q_raw = np.maximum(models()['q'].predict(frame), 0)
            r_raw = np.clip(models()['R'].predict(frame), 0, 100)
            q, r, residual = project(q_raw, r_raw, raw['Initial_Conc(mg/L)'].to_numpy(float), raw['Dosage(g/L)'].to_numpy(float))
            z = (x - lower) / scale
            risk = nn.kneighbors(z)[0].mean(axis=1) + .35 * residual / 100
            out['F'] = np.column_stack([-q, -r, z[:, 0], z[:, 2:].mean(axis=1), risk])

    ref = get_reference_directions('das-dennis', 5, n_partitions=6)
    result = minimize(ScreenProblem(), NSGA3(pop_size=210, ref_dirs=ref), ('n_gen', 100), seed=20260808, verbose=False)
    rows = []
    for x, f in zip(result.X, result.F):
        rows.append({'metal': metal, 'Initial_Conc(mg/L)': case['initial_conc'], **dict(zip(CONTROL, x)),
                     'predicted_q': -f[0], 'predicted_R': -f[1], 'KMnO4_objective': f[2], 'process_burden': f[3], 'prediction_risk': f[4]})
    return pd.DataFrame(rows), 'NSGA-III with edited context; manuscript rules'


def recommend(payload=None):
    case = normalise_payload(payload)
    baseline = predict(case)
    response = {'baseline': baseline, 'strategies': [], 'candidate_set': [], 'objectives': ['Higher q', 'Higher R', 'Lower KMnO4', 'Lower process burden', 'Lower screening risk']}
    if case['metal'] not in DATA['supports']:
        response['note'] = 'This metal is sparsely represented. Prediction only; no audited optimization scenario.'
        return response
    if any(case[k] is None for k in LABELS):
        raise ValueError('Complete the six decision controls and initial concentration before screening.')
    # Search replaces all six controls, so only fixed background changes the pool.
    background = {**case, **{key: defaults(case['metal'])[key] for key, column in FIELDS.items() if column in CONTROL}}
    pool, route = screen(json.dumps(background, sort_keys=True))
    cutoff = float(pool.prediction_risk.quantile(.65))
    eligible = pool.loc[pool.prediction_risk <= cutoff].copy()
    norm = lambda c: (eligible[c]-eligible[c].min())/(eligible[c].max()-eligible[c].min()+1e-12)
    scores = {'capacity': norm('predicted_q')-.30*norm('prediction_risk')-.15*norm('KMnO4_objective'),
              'removal': norm('predicted_R')-.30*norm('prediction_risk')-.15*norm('process_burden'),
              'balanced': .5*norm('predicted_q')+.5*norm('predicted_R')-.35*norm('prediction_risk')-.15*norm('process_burden')}
    for identifier, score in scores.items():
        row = eligible.loc[score.idxmax()]
        selected_case = {**case, **{next(k for k,c in FIELDS.items() if c==column): float(row[column]) for column in CONTROL}}
        prediction = predict(selected_case)
        assert np.allclose([prediction['q'],prediction['R']], [row.predicted_q,row.predicted_R], atol=1e-5)
        prediction['changes'] = changes(case, selected_case)
        response['strategies'].append({'id': identifier, 'title': TITLES[identifier], 'subtitle': 'Fixed manuscript score; strategies may coincide', 'result': prediction})
    for index, row in pool.iterrows():
        response['candidate_set'].append({'id': f'C{index:03d}', 'q': float(row.predicted_q), 'R': float(row.predicted_R),
                                         'chemical': float(row.KMnO4_objective), 'process': float(row.process_burden),
                                         'boundary_risk': float(row.prediction_risk), 'pareto': True, 'eligible': bool(row.prediction_risk <= cutoff)})
    response.update(note=route, risk_cutoff=cutoff)
    return response


def profile(payload=None, field='dosage'):
    if field not in ['dosage','initial_conc','kmno4_conc','ph','contact_time']:
        raise ValueError('Unsupported profile field.')
    case = normalise_payload(payload)
    column = FIELDS[field]
    lo, hi = DATA['ranges'][column][1:3]
    if column in CONTROL and case['metal'] in DATA['supports']:
        lower, upper, *_ = support(case['metal'])
        lo, hi = lower[CONTROL.index(column)], upper[CONTROL.index(column)]
    cases = [{**case, field: float(value)} for value in np.linspace(lo, hi, 17)]
    predictions = predict_many(cases)
    label, unit = LABELS[field]
    return {'field':field, 'label':label, 'unit':unit, 'baseline_x':case[field],
            'points':[{'x':p['case'][field], 'q':p['q'], 'R':p['R'], 'boundary_risk':p['decision']['boundary_risk']} for p in predictions],
            'note':'Conditional projected model profile; other inputs held fixed. It is not a measured kinetic curve or a causal effect.'}


def metadata():
    return {'defaults': defaults(), 'metal_defaults':{m:defaults(m) for m in DATA['contexts']}, 'metals': sorted(DATA['contexts']),
            'families':DATA['families'], 'feedstocks':DATA['feedstocks'], 'modifications':DATA['modifications'],
            'screened_metals':list(DATA['supports']), 'manifest':MANIFEST}
