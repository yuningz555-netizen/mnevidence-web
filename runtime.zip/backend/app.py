from pathlib import Path
import os
from threading import BoundedSemaphore

from flask import Flask, jsonify, request, send_from_directory
from werkzeug.exceptions import RequestEntityTooLarge
from model_runtime import metadata, predict, profile, recommend

DIST = Path(__file__).resolve().parents[1] / 'frontend/dist'
app = Flask(__name__, static_folder=str(DIST), static_url_path='')
app.config['MAX_CONTENT_LENGTH'] = 64 * 1024
screening_slot = BoundedSemaphore(1)


@app.get('/api/health')
def health():
    return jsonify(ok=True, service='MnEvidence-Paper', version='20261003')


@app.get('/api/metadata')
def get_metadata():
    return jsonify(metadata())


def response(operation):
    try:
        body = request.get_json(silent=True)
        if not isinstance(body, dict):
            raise ValueError('Provide a JSON object.')
        return jsonify(operation(body))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    except RequestEntityTooLarge:
        return jsonify(error='The request exceeds the 64 KB input limit.'), 413
    except Exception:
        app.logger.exception('Model operation failed')
        return jsonify(error='Model operation failed. Please try again later.'), 500


@app.errorhandler(413)
def body_too_large(error):
    return jsonify(error='The request exceeds the 64 KB input limit.'), 413


@app.after_request
def security_headers(result):
    result.headers['X-Content-Type-Options'] = 'nosniff'
    result.headers['Referrer-Policy'] = 'no-referrer'
    result.headers['X-Frame-Options'] = 'DENY'
    if request.path.startswith('/api/') or result.mimetype == 'text/html':
        result.headers['Cache-Control'] = 'no-store'
    return result


@app.post('/api/predict')
def get_prediction():
    return response(predict)


@app.post('/api/recommend')
def get_recommendation():
    if not screening_slot.acquire(blocking=False):
        result = jsonify(error='Screening is busy. Please retry in a moment.')
        result.headers['Retry-After'] = '5'
        return result, 429
    try:
        return response(recommend)
    finally:
        screening_slot.release()


@app.post('/api/profile')
def get_profile():
    return response(lambda body: profile(body.get('case', body), body.get('field','dosage')))


@app.get('/')
@app.get('/<path:path>')
def frontend(path='index.html'):
    if path.startswith('api/'):
        return jsonify(error='Unknown endpoint.'), 404
    return send_from_directory(DIST, path if (DIST/path).is_file() else 'index.html')


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=int(os.getenv('MNEVIDENCE_PORT', '8780')), debug=False)
